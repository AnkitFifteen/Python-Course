from django.shortcuts import render,redirect
from .models import pet,customer,cart,order,payment,orderdetail
from django.http import HttpResponse
from django.views.generic import DeleteView,ListView,CreateView,UpdateView,DetailView
from django.db.models import Q
from django.contrib.auth.hashers import make_password,check_password
from datetime import date
import razorpay
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseBadRequest

# Create your views here.
class petview(ListView):
    model = pet
    template_name= 'PetView.html'
    context_object_name ='petobj'

    def get_context_data(self, **kwargs):
            try:
                data = self.request.session['sessionvalue']
                context = super().get_context_data(**kwargs)
                context['session'] = data
                return context
            except:
                context = super().get_context_data(**kwargs)
                return context

class petdetail(DetailView):
    model=pet
    template_name='PetDetail.html'
    context_object_name = 'i'

class petviewcm(ListView):
    template_name= 'PetView.html'
    context_object_name ='petobj'

def petviewcmfun(request):
    petdetails = pet.cpetobj.getdata('dog')
    return render(request,'PetView.html',{'petobj':petdetails})   

def search(request):
    if request.method =="POST":
        session = request.session['sessionvalue']
        searchdata = request.POST.get('searchquery')
        petobj = pet.objects.filter(Q(name__icontains =searchdata)|Q(breed__icontains =searchdata)|Q(species__icontains =searchdata))
        return render(request,'PetView.html',{'petobj':petobj,'session':session})
    

def register(request):
    if request.method =="GET":
        return render(request,'register.html')
    elif request.method =="POST":
        firstname = request.POST.get('fn')
        email =  request.POST.get('email')
        phoneno =  request.POST.get('pn')
        password = request.POST.get('pass')
        epassword = make_password(password)

        custobj = customer(name=firstname,password=epassword,email=email,phoneno=phoneno)
        custobj.save()
        return redirect('../login/')
    


def login(request):
    if request.method=="GET":
        return render(request,'login.html')
    elif request.method =="POST":
        user = request.POST.get('username')
        password = request.POST.get('pass')

        cust = customer.objects.filter(email=user)
        
        if cust:
            custobj = customer.objects.get(email=user)

            flag = check_password(password,custobj.password)

            if flag:
                request.session['sessionvalue']=  custobj.email
                return redirect('../PetView')
            else:
                return render(request,'login.html',{'msg':'Incorrect username and Password'})
            
        else:
            return render(request,'login.html',{'msg':'Incorrect username and Password'})
        

def addtocart(request):
    productid = request.POST.get('productid')
    print(request.session['sessionvalue'])
    try:
        custsession = request.session['sessionvalue'] #email of customer
        custobj = customer.objects.get(email = custsession) #fetch record from database table using email
        print('inside the try')
        custid = custobj.id #fetch customer id using customer object
        print(productid)
        pobj = pet.objects.get(id = productid)
        print(pobj)
        flag = cart.objects.filter(cid = custobj.id,pid =productid)
        if flag:
            print('inside the flag')
            cartobj = cart.objects.get(cid = custobj.id,pid = pobj.id)
            cartobj.quantity = cartobj.quantity +1
            cartobj.totalamount = pobj.price * cartobj.quantity
            cartobj.save()
        else:
            cartobj = cart(cid = custobj,pid = pobj,quantity = 1,totalamount = pobj.price*1)
            cartobj.save()

        return redirect('../PetView')
    except:
        return redirect('../login/')


def viewcart(request):
    custsession = request.session['sessionvalue'] #email of customer
    custobj = customer.objects.get(email = custsession) 
    cartobj = cart.objects.filter(cid = custobj.id)

    return render(request,'cart.html',{'cartobj':cartobj,'session':custsession})

def cq(request):
    cemail = request.session['sessionvalue']
    pid = request.POST.get('pid')
    custobj = customer.objects.get(email = cemail)
    pobj = pet.objects.get(id = pid)
    cartobj = cart.objects.get(cid = custobj.id,pid=pobj.id)

    if request.POST.get('changequantitybutton')=='+':
        cartobj.quantity = cartobj.quantity + 1
        cartobj.totalamount = cartobj.quantity * pobj.price
        cartobj.save()

    elif request.POST.get('changequantitybutton')=='-':
        if cartobj.quantity == 1:
            cartobj.delete()
        else :
            cartobj.quantity = cartobj.quantity - 1
            cartobj.totalamount = cartobj.quantity * pobj.price
            print(cartobj.totalamount)
            cartobj.save()

    return redirect('../viewcart')

def summary(request):
    custsession = request.session['sessionvalue']
    custobj = customer.objects.get(email= custsession)
    cartobj = cart.objects.filter(cid = custobj.id)
    totalbill = 0
    for i in cartobj:
        totalbill = i.totalamount + totalbill
    
    return render(request,'summary.html',{'session':custsession,'cartobj': cartobj,'totalbill':totalbill})


def placeorder(request):
    if request.method =="POST":
        fn = request.POST.get('fn')
        print(fn)
        ln = request.POST.get('ln')
        address = request.POST.get('address')
        city = request.POST.get('city')
        state = request.POST.get('state')
        pincode = request.POST.get('pincode')
        phoneno = request.POST.get('phoneno')

        datev = date.today()
        print(datev)
        orderobj = order(firstname = fn, lastname= ln, address = address,city=city,state=state,pincode=pincode,phoneno= phoneno,orderdate=datev,orderstatus ="pending")
        print(orderobj)
        orderobj.save()

        ono = str(orderobj.id) + str(datev).replace('-','')
        orderobj.ordernumber = ono
        orderobj.save()
        custsession = request.session['sessionvalue']
        custobj = customer.objects.get(email= custsession)
        cartobj = cart.objects.filter(cid = custobj.id)
        totalbill=0
        for i in cartobj:
                totalbill = i.totalamount + totalbill

        # from django.core.mail import EmailMessage

        # sm = EmailMessage('Order placed','order placed from pet store application. Total bill for your order is '+str(totalbill),to=['prachig@itvedant.com'])
        # sm.send()
        
        
        # authorize razorpay client with API Keys.
        razorpay_client = razorpay.Client(
            auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))
    
    

        currency = 'INR'
        amount = 20000  # Rs. 200
    
        # Create a Razorpay Order
        razorpay_order = razorpay_client.order.create(dict(amount=amount,
                                                        currency=currency,
                                                        payment_capture='0'))
    
        # order id of newly created order.
        razorpay_order_id = razorpay_order['id']
    
        # we need to pass these details to frontend.
        context = {}
        context['razorpay_order_id'] = razorpay_order_id
        context['razorpay_merchant_key'] = settings.RAZORPAY_KEY_ID
        context['razorpay_amount'] = amount
        context['currency'] = currency
        return render(request,'payment.html',{'orderobj':orderobj,'session':custsession,'cartobj':cartobj,'totalbill':totalbill,'context':context})


def paymentsuccess(request):
    orderid = request.GET.get('order_id')
    tid = request.GET.get('payment_id')
    usersession = request.session['sessionvalue']
    print(usersession)
    customerobj = customer.objects.get(email=usersession)
    print(customerobj.id)
    cartobj = cart.objects.filter(cid = customerobj.id)

    orderobj = order.objects.get(ordernumber = orderid)
    paymentobj = payment(transactionid = tid, paymentstatus='paid',customerid=customerobj,oid = orderobj)
    paymentobj.save()
    for i in cartobj:
        orderdetailobj = orderdetail(paymentid = paymentobj,ordernumber = orderid, productid = i.pid,customerid = i.cid,quantity = i.quantity,totalprice = i.totalamount)
        orderdetailobj.save()
        i.delete()
    
    return render(request,'payment_success.html',{'session':usersession,'payobj':paymentobj})


def logout(request):
    del(request.session['sessionvalue'])
    return redirect('../login/')



