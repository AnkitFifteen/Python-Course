from django.shortcuts import render,HttpResponse,redirect

from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from django.contrib.auth import login, authenticate
from .forms import RegisterForm
from .models import ImageUpload
# Create your views here.

def register(request):

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('home')
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

from django.contrib.auth import views as auth_views

def login_view(request):
    return auth_views.LoginView.as_view(template_name='login.html')(request)


from django.contrib.auth import views as auth_views

def logout_view(request):
    return auth_views.LogoutView.as_view()(request)

from django.contrib.auth.decorators import login_required
from django.shortcuts import render

@login_required
def home(request):
    return render(request, 'home.html')


def upload_image(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        image = request.FILES.get('image')
        
        if title and image:
            ImageUpload.objects.create(title=title, image=image)
            return redirect('upload_image')
        else:
            return HttpResponse("Please provide both title and image.")
    
    return render(request, 'upload_image.html')