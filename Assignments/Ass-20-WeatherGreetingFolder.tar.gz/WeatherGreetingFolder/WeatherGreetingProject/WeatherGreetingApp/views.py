from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime, date, time, timezone
# Create your views here.

def greeting(request):
    dt = datetime.now()
    msg = "unknown"
    if dt.hour < 12:
        msg = "Good Morning"
    elif dt.hour < 16 and dt.hour > 12:
        msg = "Good Afternoon"
    else:
        msg = "Good Evening"
    return HttpResponse(msg)
